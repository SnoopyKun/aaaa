var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var JsonDataSource;
(function (JsonDataSource) {
    var SetJsonDataToCellCommand = /** @class */ (function (_super) {
        __extends(SetJsonDataToCellCommand, _super);
        function SetJsonDataToCellCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SetJsonDataToCellCommand.prototype.execute = function () {
            var _this = this;
            var commandParam = this.CommandParam;
            try {
                var jsonData_1 = this.getJsonData(commandParam);
                commandParam.CellInfos.forEach(function (cellInfo) {
                    var cell = _this.getCell(cellInfo.Cell);
                    if (!cell) {
                        return;
                    }
                    var data = _this.getPropertyValue(jsonData_1, cellInfo.PropertyName);
                    if (data === undefined) {
                        data = null;
                    }
                    cell.setText(data);
                });
            }
            catch (e) {
                alert(e.message);
            }
        };
        SetJsonDataToCellCommand.prototype.getPropertyValue = function (data, propertyName) {
            data = _super.prototype.getPropertyValue.call(this, data, propertyName);
            if (Array.isArray(data) && data.length > 0) {
                data = data[0];
            }
            return data;
        };
        SetJsonDataToCellCommand.prototype.getJsonData = function (commandParam) {
            var data = _super.prototype.getJsonData.call(this, commandParam);
            if (JsonDataSource.Common.IsEmpty(data)) {
                data = {};
            }
            if (Array.isArray(data) && data.length > 0) {
                data = data[0];
            }
            return data;
        };
        return SetJsonDataToCellCommand;
    }(JsonDataSource.JsonDataSourceCommandBase));
    JsonDataSource.SetJsonDataToCellCommand = SetJsonDataToCellCommand;
})(JsonDataSource || (JsonDataSource = {}));
Forguncy.Plugin.CommandFactory.registerCommand("JsonDataSource.SetJsonDataToCellCommand, JsonDataSource", JsonDataSource.SetJsonDataToCellCommand);
//# sourceMappingURL=SetJsonDataToCellCommand.js.map