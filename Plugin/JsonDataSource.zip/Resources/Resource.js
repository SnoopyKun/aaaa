var JsonDataSource;
(function (JsonDataSource) {
    var RS_JP = {
        Error_InvalidJson: "不正なJSON文字列：{0}",
        Error_DetailInfo: "配列インデックスが「{1}」の値「{0}」はJSONデータにおいて不正な値です。\r\nエラーメッセージ：{2}"
    };
    var RS_CN = {
        Error_InvalidJson: "非法JSON字符串：{0}",
        Error_DetailInfo: "json数据源数组中第'{1}'项的值'{0}'不合法；\r\n错误信息：{2}"
    };
    var RS_KO = {
        Error_InvalidJson: "Invalid json string: {0}",
        Error_DetailInfo: "The value '{0}' is invalid which array index is '{1}' in json data.\r\nError message:{2}"
    };
    var RS_EN = {
        Error_InvalidJson: "Invalid json string: {0}",
        Error_DetailInfo: "The value '{0}' is invalid which array index is '{1}' in json data.\r\nError message:{2}"
    };
    var RSHelper = /** @class */ (function () {
        function RSHelper() {
        }
        RSHelper.getRS = function () {
            switch (Forguncy.RS.Culture) {
                case "CN" /* Forguncy.ForguncySupportCultures.Chinese */:
                    return RS_CN;
                case "JA" /* Forguncy.ForguncySupportCultures.Japanese */:
                    return RS_JP;
                case "KR" /* Forguncy.ForguncySupportCultures.Korean */:
                    return RS_KO;
                default:
                    return RS_EN;
            }
        };
        return RSHelper;
    }());
    JsonDataSource.RSHelper = RSHelper;
})(JsonDataSource || (JsonDataSource = {}));
//# sourceMappingURL=Resource.js.map